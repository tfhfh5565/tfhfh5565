<?php
$link = new mysqli('localhost','数据库用户名','数据库密码','数据库库明');
mysqli_set_charset($link, 'utf8');
if ($link->connect_error) {
    die("连接失败: " . $conn->connect_error);
}
$ranking = "kano_rank";//排行榜表名